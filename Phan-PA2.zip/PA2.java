/**
 * Author: Khoa Phan
 * Course: CS146-06
 * Description: The program simulates a hospital waiting room using binary search tree (BST) and separate chaining hash table.
 * Simulations: 	
 * BST functions:
 * 					Build up a BST full of 20 patients
 * 					Insert a patient with priority to BST
 * 					Delete a patient with priority to BST
 * 					Sorted the list in ascending order
 * Hash functions:	
 * 					Create a 11-slot table with 20 patients 
 * 					Insert a patient with priority to table
 * 					Delete a patient with priority out of table
 * 					Search a patient based on priority number
 * 					Make a list of patients
 */

import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;

public class PA2
{
	private static int roomCapacity = 20; // default room always maintain at 20 people.
	private static int size = 100; // the range of priority of first 20 people
	private static Scanner input;
	private static int BST_size = 0;
	private static int slot = 11; // default slot of hash table = 11 for 20 people
	private static int Hash_size = 0;
	private static BST_Node root = null;
	
	
	
	public static void main(String[] arg)
	{
		String name; // hold name
		int priority ; // hold priority
		char repeat = 'r'; // repeat the menu
		
		input = new Scanner(System.in);
		Random random = new Random();
		
		String[] names = { "Dung", "Phuc", "Ryan", "Aron", "Kris","Jenny", "Bob", "Jason",
		            "Vivian", "Julian", "Vinh", "Julie", "Jacob", "Kevin", "Rose", "Jack",  "Katy",
		            "Alissa", "Tom", "Jerry", "Malvin", "Justin", "Lee", "Zhang", "Fa", "Bel",  "Ella",
		            "Austin", "Zac", "Jake", "Logan", "Ken"};
		
		// array hold priority 
		ArrayList<Integer> priorityArray = new ArrayList<Integer>(size);
		for(int i = 1; i <= size; i++) 
        {
            priorityArray.add(i);
        } 		
		
		// an empty chaining hash table with given size (11)
		hashTable[] chainingtable = new hashTable[slot];
		for(int i = 0; i < slot; i++)
		{
			chainingtable[i] = new hashTable();
        }
		
		binarysearchTree waitingroom = new binarysearchTree(); // create an empty BST
		
		Patient[] mainArray = new Patient[roomCapacity]; // hold patient name and priority without repeating	
		for(int i = 0; i < roomCapacity; i++)
        {
			mainArray[i] = new Patient();
			int index = random.nextInt(priorityArray.size());
			mainArray[i].setPatientName(names[i]);
			mainArray[i].setPriority(priorityArray.remove(index));
        }
		do
		{
			
			System.out.println("\t\t\tWelcome to Hospital waiting room");    	        
		    System.out.println("**********************************************************************");	
		    System.out.println("\t\t\t\t Menu ");
		    System.out.println("Binary seach tree function:");
		    System.out.println("1.Build up a Patients Binary Search Tree");
			System.out.println("2.Insert a patient to Binary Search Tree based on his/her priority code");
			System.out.println("3.Delete a patient from Binary Search Tree");
			System.out.println("4.Print out a sorted list of patients according to the priority code from BTS");
			System.out.println("_____________________________________________________________________________");
			System.out.println("Hash Table function");
			System.out.println("5. Create a 11-slot separate chianing Hash Table");
			System.out.println("6. Insert a patient to the chaining Hash Table");
			System.out.println("7. Delete a patient from the chaning Hash Table");
			System.out.println("8. Search a patient's name by his/her priority");
			System.out.println("9. Make a list of patients in the hash table");
			System.out.println("0. Exit");
		    System.out.print("Please choose an option that you want to operate (0-9): ");
		    
		    switch (input.nextInt()) //menu
		    {
		    case 1:		// build BST tree    		
		    	if (waitingroom.getSize() > 0 )
		    	{
		    		System.out.println("The Binary Search Tree is already built up");
                    break;
		    	}
		    		waitingroom = new binarysearchTree(mainArray);					
					waitingroom.inOrder(binarysearchTree.getRoot());					
					break;
					
			case 2:		//bst insert				
					if(waitingroom.getSize() == 20)
						{
						System.out.println("The waiting room is full of 20 people");
						System.out.println("Please delete one patient out of the waiting room first");
						}
					else							
						{
							System.out.print("Enter name of new patient: ");
							name = input.next();							
							System.out.print("Enter new priority(0<priority): ");
							priority = input.nextInt();	
							int index = 0;
							if(priority > 0) 
							{
							Patient patientInfo = new Patient(name, priority);
							if(mainArray[index].getPriority() < priority) //check if the priority number is duplicated
				 				checkduplicate(mainArray, index, priority);
							binarysearchTree.BST_Insert(new BST_Node(patientInfo));
							System.out.println(patientInfo.toString());
							System.out.println("The waiting room have been updated");
							waitingroom.inOrder(binarysearchTree.getRoot());	
							}
							else
							{
								System.out.println("Please enter a priority number greater than 0");
							}
						}
				break;

					
				case 3:		//bst delete
					if (waitingroom.getSize() == 0)
					{
						System.out.println("The list of patients is empty so you cannot do the delete operation.");
					}
					else if (waitingroom.getSize() < 20 && waitingroom.getSize() != 0)
					{
						System.out.println("You can only delete one patient at a time");
						System.out.println("You need to add a new patient to make the list full of 20 patients.");
					}
					else 
					{
						System.out.println("****************************************************************");
						waitingroom.inOrder(binarysearchTree.getRoot());							
						System.out.print("Please enter the priority number of the patient you want to delete: ");
						priority = input.nextInt();
					
						
						BST_Node Node = binarysearchTree.BST_Search(binarysearchTree.getRoot(), new Patient(null, priority));
						
						if (Node == null)
							System.out.println("The priority number you entered does not exists " + priority);
						else
						{							
							waitingroom.BST_Delete(waitingroom, Node);							
							System.out.println("The patient with the selected priority is deleted: ");
							System.out.println(Node.toString());
							System.out.println("The waiting room have been updated");
							waitingroom.inOrder(binarysearchTree.getRoot());				
						}
												
					}
					break;
				
				case 4:		//print out the patient list in increasing order
					if (waitingroom.getSize() == 0)
						System.out.println("There is no patient in the list");
					else
						System.out.println("A ascending sorted list of patients based on patient's priority numbers ");
					waitingroom.inOrder(binarysearchTree.getRoot());					
					break;
				
				case 5: // build the table with 11 slot
					hashTable.hashInsert(chainingtable, mainArray);					
					System.out.println("11 slots separate chaining Hash Table for 20 patients: ");
					hashTable.print(chainingtable);
					break;
					
				case 6: // hash insert
					if (chainingtable[slot-1].getSize() != 20)
						
					{
						System.out.print("Please enter the name of new patient: ");
						name = input.next();
						System.out.print("Enter new patient's priority(>0): ");
						priority = input.nextInt();		
						int hash1 = 0;
						if(priority > 0)
						{
						Patient patient = new Patient(name, priority);	
						if(chainingtable[hash1].getKey() < priority) //check if the priority number is duplicated
			 				checkduplicate(mainArray, hash1, priority);
						int hash = priority % slot;
						hashTable.Insert(chainingtable[hash], new Hash_Node(patient));
						System.out.println("New patient has been added: " + patient.toString());						
						}
					}
					else
					{
						System.out.println("The waiting list is full");
						System.out.println("You have to delete 1 patient first");
					}
					break;
					
				case 7: //hash delete
					if (chainingtable[slot-1].getSize() != 0 && chainingtable[slot-1].getSize() > 19)
					{
						hashTable.print(chainingtable);
						System.out.print("Please enter the priority of the patient you want to delete ");
						priority = input.nextInt();
						Hash_Node tempNode = hashTable.hashSearch(chainingtable, new Patient(null, priority));
						if (tempNode == null)
							System.out.println("The priority: " + priority + " is invalid.");
						else
						{
							hashTable.hashDelete(chainingtable, tempNode);
							System.out.println("Selected patient is deleted from the list: " + tempNode.toString());
						}
					}
					else if (chainingtable[slot-1].getSize() == 0)
					{
						System.out.println("The waiting list is empty");
					}
					else
					{
						System.out.println("The list is containing 19 patients currently");
						System.out.println("You have to insert a new patient before deleting another patient");
					}
					break;
				case 8: // hash search
					System.out.print("Please enter the priority of the patient you want to find: ");
					priority = input.nextInt();
					Hash_Node tempnode = hashTable.hashSearch(chainingtable, new Patient(null, priority));
					if (tempnode == null)
						System.out.println("The priority you entered: " + priority + " is not in hash table.");
					else
					{
						System.out.println("Name of the patient with selected priority is : " + tempnode.toString());						
					}
					break;
				case 9: // hash make a list of patients
					System.out.println("A list of patient in Hash table: ");
					hashTable.print(chainingtable);
					break;
				case 0:	// exit the program				
					repeat = '#';
					break;
				default: // return menu if user entered the option that is not in the list  
					System.out.println("Please choose from 0 to 9");					
		    }					 
		}					
		while (repeat != '#' );
	}
	
	/**
	 * avoid two or more patients to have same priority
	 * @param array a Patient array
	 * @param index an Integer representing an index of patient
	 * @param priority an Integer representing a priority of patient
	 */	
	private static void checkduplicate(Patient[] mainArray, int index, int priority )
	{
		
		for(int i = 0; i<roomCapacity; i++) 
		{
			if(i != index && mainArray[i].getPriority() == priority)
			{
				mainArray[i].setPriority(mainArray[i].getPriority() +1 );
				checkduplicate(mainArray, i, mainArray[i].getPriority());
			}
		}
	}



	public static class binarysearchTree
	{			
		/** 
		 * create a default bst
		 */
		public binarysearchTree()
		{
		}				
		
		/**
		 * Create a bst from array of patient 
		 */
		public binarysearchTree(Patient[] currentPatient)
		{
			
			for (int i = 0; i < currentPatient.length; i++)
			{
				BST_Node Node = new BST_Node(currentPatient[i]);
				BST_Insert(Node);
			}
		}
		
		/**
		 * insert a node to bst
		 * @param z is the node is inserting to bst
		 */
		public static void BST_Insert(BST_Node z)
		{
			BST_Node y = null; /* trailing pointer, p of x */
			BST_Node x = root;
			
			while (x != null)
			{
				y = x;
				if (z.key.getPriority() < x.key.getPriority())
					x = x.left;
				else
					x = x.right;
				z.parent = y;
			}
			if (y == null)
				root = z; /* tree T was empty */
			else if (z.key.getPriority() < y.key.getPriority())
				y.left = z;
			else
				y.right = z;
			
			BST_size++;			
		}
		
		/**
		 * print out binary tree in increasing order
		 * x is a node of the bst
		 */				
		public void inOrder(BST_Node x)
		{
	        if(x != null)
	        {
	            inOrder(x.left);
	            System.out.println(x.key.toString());	            
	            inOrder(x.right);
	        }
	
		}
		
		/**
		 * find minimum node of the x node
		 * @param x is a node of the bst
		 * @return x-minimun
		 */		
		public static BST_Node BST_Min(BST_Node x)
		{
			while (x.left != null)
				x = x.left;
			return x;
		}
				
		/**
		 * swap nodes
		 * @param T binary tree 
		 * @param u node will be delete
		 * @param v node will move 
		 */
		public static void TransPlant(binarysearchTree T, BST_Node u, BST_Node v)
		{
			/*Handle u is root of T */
			if (u.parent == null)
				root = v;
			/* if u is a left child */
			else if (u == u.parent.left)
				u.parent.left = v;
			/* if u is a right child */
			else
				u.parent.right = v;
			/* update v.parent if v is non-NIL */
			if (v != null)
				v.parent = u.parent;
		}
		
		/**
		 * search node in BST
		 * @param x is root of the BST
		 * @param k is the node we need to find
		 * @return the node/nil
		 */
		public static BST_Node BST_Search(BST_Node x, Patient k)
		{
			 if(x == null || k.getPriority() == x.key.getPriority())
	            return x;
	        else if(k.getPriority() < x.key.getPriority())
	            return BST_Search(x.left, k);
	        else
	            return BST_Search(x.right, k);
	    }
		
		
		/**
		 * delete a node in bst
		 * @param T is bst
		 * @param z is the node will be deleted
		 */
		public void BST_Delete(binarysearchTree T, BST_Node z)
		{
			/* a) z has no left */
			if (z.left == null)
				TransPlant(T, z, z.right);
			/* b) z has a left child but no right child */
			else if (z.right == null)
				TransPlant(T, z, z.left);
			/* c) z has two children */
			else 
			{
				BST_Node y = BST_Min(z.right); /* find z's successor */
				if (y.parent != z) /* y lies within y's subtree but is not the root of this subtree */ 
				{
					TransPlant(T, y, y.right);
					y.right = z.right;
					y.right.parent = y;
				}
				/* d) if y is z's right child */
				TransPlant(T, z, y);
				y.left = z.left; /* replace y's left child by z's left child */
				y.left.parent = y;				
			}	
			BST_size--;
		}
		
		
		/**
		 * get size of bst
		 * @return size of bst
		 */
		public int getSize()
		{
			return BST_size;
		}		
		
		/**
		 * get root of bst
		 * @return root bst
		 */
		public static BST_Node getRoot()
		{
			return root;
		}		
	}
	/**
	 * create a class node for BST
	 */
	public static class BST_Node
	{
		
		private Patient key;
		private BST_Node left, right, parent;
				
		/**
		 * create a class node with key
		 * @param node with patient's key
		 */
        public BST_Node(Patient currentPatient)
        {
            setKey(currentPatient);
        }
        /**
		 * setter for key
		 * @param key of node
		 */
		public void setKey(Patient key) 
		{
			this.key = key;
		}

		/**
         * getter for key
         * @return key
         */
		public Patient getKey() 
		{
			return this.key;
		}
	
		/**
		 * print the patient's information
		 */
		public String toString()
		{
			return this.key.toString();
		}
	}
	
	public static class hashTable
	{
		private Hash_Node h = null;
		
		/**
		 * create a linked list
		 */
		public hashTable()
	    {				
	    }
		
		/**
	     * insert a node to linked list
	     * @param hashTable is the linked list
	     * @param x is the node will be inserted
	     */
		public static void Insert(hashTable hashTable, Hash_Node x)
	    {
	    	x.next = hashTable.h;
	    	if (hashTable.h != null)
	    		hashTable.h.prev = x;
	    	hashTable.h = x;
	    	x.prev = null;
	    	Hash_size++;	    	
	    	
	    }
		/**
	     * insert from patient list to hash table
	     * @param hashTable is hash table
	     * @param patient is array contains 20 patients
	     */
		public static void hashInsert(hashTable[] hashTable, Patient[] currentPatient)
	    {
	    	if (Hash_size < 20)
		    	for (int i = 0; i < currentPatient.length; i++)
				{
					int index = currentPatient[i].getPriority() % 11;/// note 11
					Insert(hashTable[index], new Hash_Node(currentPatient[i]));
				}
	    }						
		/**
		 * search a node in linked list
	     * search key in hash table
	     * @param hashTable is hash table
	     * @param z is the key needed to find
	     * @return null/node with key
	     */		
		public static Hash_Node hashSearch(hashTable[] hashTable, Patient z)
	    {
	    	for (int i = 0; i < hashTable.length; i++)
	    	{
	    		Hash_Node temp = hashTable[i].h;
	    	
    		while (temp != null)
    		{
    			if (temp.key.cp(z) == 0)
    				return temp;
    			temp = temp.next;
    		}
    	}
    	return null;
	}	
		/**
		 * delete a node in linked list
	     * delete a node in hash table
	     * @param hashTable is hash table
	     * @param x is the node needed to delete	  
	     */	
		
		public static void hashDelete(hashTable[] hashTable, Hash_Node x)
	    {
	    	for (int i = 0; i < hashTable.length; i++)
	    	{
	    		Hash_Node temp = hashTable[i].h;
	    		while (temp != null)
	    		{
	    			if (temp.key == x.key)
	    			{
	    				if (x.prev != null)
	    		    		x.prev.next = x.next;
	    		    	else
	    		    		hashTable[i].h = x.next;
	    		    	if (x.next != null)
	    		    		x.next.prev = x.prev;
	    		    	Hash_size--;
	    			}
	    			temp = temp.next;
	    		}
	    	}
	    }
		
		/**
		 * print out hash table
		 * @param table_X
		 */
		 public static void print(hashTable[] table_X)
		    {		    	
			    for (int i = 0; i < slot; i++)
				{
					Hash_Node Node = table_X[i].h;
					System.out.print("Reminder = " + i + "\n");					
					while (Node != null)
					{
						System.out.print(Node.toString() + "\n");
						Node = Node.next;
					}					
				}
		    }
		 /**
		  * getter for size of the hash table
		  * @return size
		  */
		 public int getSize()
		    {
		    	return Hash_size;
		    }	
		 
		 /**
		  * getter for Key of the hash table
		  * @return size
		  */
		 public int getKey() 
			{			
				return 0;
			}
	}	
	
	//create a class node for hash table
	public static class Hash_Node
	{
		private Patient key;
    	private Hash_Node next, prev;    	
    	
    	/**
    	 * create node with patient's key
    	 * @param patient
    	 */
    	public Hash_Node(Patient currentPatient)
    	{
    		setKey(currentPatient);
    	}
    	
    	/**
    	 * setter for key
    	 * @param patient
    	 */
    	public void setKey(Patient currentPatient)
        {
        	this.key = currentPatient;
        }
        
    	/**
    	 * getter for key
    	 * @return key
    	 */
        public Patient getKey()
        {
        	return key;
        }

        /**
         * print out the key with patient's information
         */
		public String toString()
        {
        	return key.toString();
        }
    }	
	/**
	 * A class representing patients with their names and priority numbers
	 */
	
	public static class Patient
	{

		String patientName;
		int priorityNumber;		

		/**
		 * Constructor: requires specific name and priority
		 * @param name a String representing a name of patient
		 * @param priority an Integer representing a priority number of patient
		 */
		public Patient(String name, int priority)
		{
			this.patientName = name;
			this.priorityNumber = priority;
			
		}

		/**
		 * Constructor: requires nothing
		 */
		public Patient()
		{
		}

		/**
		 * Sets a name to this patient
		 * @param name a String representing a name of patient
		 */
		public void setPatientName(String name)
		{
			this.patientName = name;
		}

		/**
		 * Sets a priority number to this patient
		 * @param priority an Integer representing a priority number of patient
		 */
		public void setPriority(int priority)
		{
			this.priorityNumber = priority;
		}

		/**
		 * Returns the name of this patient
		 * @return the name of patient
		 */
		public String getPatientName()
		{
			return patientName;
		}

		/**
		 * Returns the priority number of this patient
		 * @return the priority number of this patient
		 */
		public int getPriority()
		{
			return priorityNumber;
		}

		/**
		 * Returns a String representation of this patient
		 * @return a String representation of this patient
		 */
		public String toString()
		{
			return "Patient:" + this.patientName + "\t\tPriority number: " + this.priorityNumber;
		}			
		
		/**
		 * compare 2 patients based on their priority numbers
		 * @param patients
		 * @return 0 if ==
		 * @return -1 if <
		 * @return 1 if >
		 */
		public int cp(Patient patient)
		{
			if(this.getPriority() == patient.getPriority())
			{
				return 0;
			}
			else if (this.getPriority() < patient.getPriority())
			{
				return -1;
			}
			else
				return 1;
		}
	}		
}


